package com.atmconnect.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.atmconnect.ble.*
import com.atmconnect.geo.*
import com.atmconnect.security.ATMSecurityManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ATMViewModel — ViewModel principal que orquestra BLE + Geo + Security.
 *
 * Expõe um [UiState] único e imutável para a UI (Compose/View).
 * Toda lógica de negócio fica aqui; a UI apenas observa e dispara intents.
 */
@HiltViewModel
class ATMViewModel @Inject constructor(
    private val bleService:      ATMBleService,
    private val geoService:      ATMGeoService,
    private val securityManager: ATMSecurityManager
) : ViewModel() {

    // -------------------------------------------------------------------------
    // UI STATE (único ponto de verdade)
    // -------------------------------------------------------------------------

    private val _uiState = MutableStateFlow(ATMUiState())
    val uiState: StateFlow<ATMUiState> = _uiState.asStateFlow()

    private val _sideEffects = MutableSharedFlow<SideEffect>()
    val sideEffects: SharedFlow<SideEffect> = _sideEffects.asSharedFlow()

    // -------------------------------------------------------------------------
    // INIT — observa os serviços em background
    // -------------------------------------------------------------------------

    init {
        observeBleState()
        observeBleEvents()
        observeGeoLocation()
    }

    private fun observeBleState() {
        viewModelScope.launch {
            bleService.bleState.collect { state ->
                _uiState.update { current ->
                    current.copy(
                        bleState       = state,
                        isConnected    = state is BleState.Connected,
                        isScanning     = state is BleState.Scanning,
                        isConnecting   = state is BleState.Connecting || state is BleState.Reconnecting,
                        connectedATM   = (state as? BleState.Connected)?.device,
                        errorMessage   = (state as? BleState.Error)?.message
                    )
                }
            }
        }
        viewModelScope.launch {
            bleService.atmDevices.collect { devices ->
                _uiState.update { it.copy(discoveredATMs = devices) }
            }
        }
    }

    private fun observeBleEvents() {
        viewModelScope.launch {
            bleService.events.collect { event ->
                when (event) {
                    is BleEvent.ConnectingStep -> {
                        _uiState.update { it.copy(connectingStep = event.step, connectingStepDesc = event.description) }
                    }
                    is BleEvent.Connected -> {
                        _sideEffects.emit(SideEffect.ShowSnackbar("ATM conectado: ${event.device.name}"))
                        loadATMInfo(event.device)
                    }
                    is BleEvent.Disconnected -> {
                        _sideEffects.emit(SideEffect.ShowSnackbar("ATM desconectado"))
                    }
                    is BleEvent.DataReceived -> {
                        handleDataReceived(event.data)
                    }
                    else -> {}
                }
            }
        }
    }

    private fun observeGeoLocation() {
        viewModelScope.launch {
            geoService.locationUpdates().collect { location ->
                _uiState.update { current ->
                    val proximity = current.connectedATM?.let { atm ->
                        // Em produção: ATM tem coordenadas reais do cadastro
                        geoService.validateProximity(location, -23.5505, -46.6333, atm.rssi)
                    }
                    current.copy(
                        userLocation = location,
                        proximityResult = proximity
                    )
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // INTENTS (ações do usuário)
    // -------------------------------------------------------------------------

    fun startScan() {
        _uiState.update { it.copy(errorMessage = null) }
        bleService.startScan()
    }

    fun stopScan() = bleService.stopScan()

    fun connectToATM(device: ATMDevice) {
        _uiState.update { it.copy(selectedATM = device, connectingStep = 0) }
        bleService.connectToATM(device.address)
    }

    fun disconnect() = bleService.disconnect()

    /**
     * Inicia saque após todas as validações de segurança.
     */
    fun requestDispense(amountBRL: Double) {
        val state = _uiState.value

        viewModelScope.launch {
            // Validações
            if (!state.isConnected) {
                _sideEffects.emit(SideEffect.ShowError("ATM não está conectado"))
                return@launch
            }
            val proximity = state.proximityResult
            if (proximity != null && !proximity.isWithinRange) {
                _sideEffects.emit(SideEffect.ShowError("Você está longe do ATM (${proximity.fusedDistanceMeters.toInt()}m). Aproxime-se."))
                return@launch
            }
            if (amountBRL < 20) {
                _sideEffects.emit(SideEffect.ShowError("Valor mínimo: R$ 20,00"))
                return@launch
            }
            if (amountBRL > 3000) {
                _sideEffects.emit(SideEffect.ShowError("Valor máximo: R$ 3.000,00"))
                return@launch
            }

            _uiState.update { it.copy(isProcessingDispense = true) }

            // Obtém token de sessão do servidor (em produção: via API REST autenticada)
            val sessionToken = generateSessionToken()

            val result = bleService.dispenseNotes(
                amount       = (amountBRL * 100).toLong(),  // em centavos
                sessionToken = sessionToken
            )

            result.fold(
                onSuccess = { dispenseResult ->
                    _uiState.update {
                        it.copy(
                            isProcessingDispense = false,
                            lastDispenseResult   = dispenseResult
                        )
                    }
                    _sideEffects.emit(SideEffect.DispenseSuccess(dispenseResult))
                },
                onFailure = { error ->
                    _uiState.update { it.copy(isProcessingDispense = false) }
                    _sideEffects.emit(SideEffect.ShowError(error.message ?: "Erro no saque"))
                }
            )
        }
    }

    // -------------------------------------------------------------------------
    // INTERNALS
    // -------------------------------------------------------------------------

    private fun loadATMInfo(device: ATMDevice) {
        // Em produção: consulta API para obter dados completos do ATM
        // (endereço, horário de funcionamento, saldo disponível, etc.)
    }

    private fun handleDataReceived(data: ByteArray) {
        // Processa dados assíncronos enviados pelo ATM (status, alertas, etc.)
    }

    private fun generateSessionToken(): String {
        return java.security.SecureRandom().let { rng ->
            ByteArray(32).also { rng.nextBytes(it) }.joinToString("") { "%02x".format(it) }
        }
    }

    override fun onCleared() {
        super.onCleared()
        bleService.cleanup()
    }
}

// =============================================================================
// UI STATE
// =============================================================================

data class ATMUiState(
    val bleState:            BleState          = BleState.Idle,
    val isScanning:          Boolean           = false,
    val isConnecting:        Boolean           = false,
    val isConnected:         Boolean           = false,
    val isProcessingDispense:Boolean           = false,
    val discoveredATMs:      List<ATMDevice>   = emptyList(),
    val selectedATM:         ATMDevice?        = null,
    val connectedATM:        ATMDevice?        = null,
    val userLocation:        UserLocation?     = null,
    val proximityResult:     ProximityResult?  = null,
    val connectingStep:      Int               = 0,
    val connectingStepDesc:  String            = "",
    val lastDispenseResult:  DispenseResult?   = null,
    val errorMessage:        String?           = null
)

sealed class SideEffect {
    data class ShowSnackbar(val message: String)         : SideEffect()
    data class ShowError(val message: String)            : SideEffect()
    data class DispenseSuccess(val result: DispenseResult): SideEffect()
}
