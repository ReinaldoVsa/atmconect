package com.atmconnect.geo

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.MutableStateFlow
import javax.inject.Inject
import javax.inject.Singleton
import com.atmconnect.ble.ATMDevice
import kotlin.math.*

/**
 * ATMGeoService — Geolocalização de alta precisão para validação de proximidade ATM.
 *
 * Funcionalidades:
 *  - Localização contínua via GPS + Network fusion (FusedLocationProvider)
 *  - Cálculo de distância ATM → usuário via Haversine
 *  - Validação de proximidade: bloqueia saque se usuário > [MAX_DISTANCE_METERS]
 *  - Geofence por ATM: alerta quando se aproxima de ATM compatível
 *  - Histórico de localizações para auditoria
 */
@Singleton
class ATMGeoService @Inject constructor(
    private val context: Context
) {
    companion object {
        const val MAX_DISTANCE_METERS   = 50.0   // máximo permitido para saque
        const val IDEAL_DISTANCE_METERS = 10.0   // distância ideal para BLE
        const val LOCATION_INTERVAL_MS  = 2_000L
        const val FASTEST_INTERVAL_MS   = 1_000L
        const val GEOFENCE_RADIUS_M     = 100f
    }

    private val fusedClient = LocationServices.getFusedLocationProviderClient(context)
    private val geofencingClient = LocationServices.getGeofencingClient(context)

    private val _currentLocation = MutableStateFlow<UserLocation?>(null)
    val currentLocation: StateFlow<UserLocation?> = _currentLocation

    private val _geoState = MutableStateFlow<GeoState>(GeoState.Idle)
    val geoState: StateFlow<GeoState> = _geoState

    // -------------------------------------------------------------------------
    // LOCALIZAÇÃO CONTÍNUA
    // -------------------------------------------------------------------------

    /**
     * Flow de atualizações de localização em tempo real.
     * Emite a cada [LOCATION_INTERVAL_MS] ms ou quando há movimento.
     */
    fun locationUpdates(): Flow<UserLocation> = callbackFlow {
        if (!checkPermissions()) {
            _geoState.value = GeoState.Error("Permissão de localização negada")
            close()
            return@callbackFlow
        }

        val request = LocationRequest.Builder(LOCATION_INTERVAL_MS)
            .setPriority(Priority.PRIORITY_HIGH_ACCURACY)
            .setMinUpdateIntervalMillis(FASTEST_INTERVAL_MS)
            .build()

        val callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { location ->
                    val userLoc = UserLocation(
                        latitude  = location.latitude,
                        longitude = location.longitude,
                        accuracy  = location.accuracy,
                        altitude  = location.altitude,
                        timestamp = location.time
                    )
                    _currentLocation.value = userLoc
                    _geoState.value = GeoState.Active(userLoc)
                    trySend(userLoc)
                }
            }
        }

        fusedClient.requestLocationUpdates(request, callback, null)
        _geoState.value = GeoState.Requesting

        awaitClose { fusedClient.removeLocationUpdates(callback) }
    }

    /**
     * Obtém a última localização conhecida (não bloqueia).
     */
    suspend fun getLastLocation(): UserLocation? {
        if (!checkPermissions()) return null
        return try {
            val loc = fusedClient.lastLocation.await()
            loc?.let {
                UserLocation(it.latitude, it.longitude, it.accuracy, it.altitude, it.time)
            }
        } catch (e: Exception) {
            null
        }
    }

    // -------------------------------------------------------------------------
    // CÁLCULO DE DISTÂNCIA
    // -------------------------------------------------------------------------

    /**
     * Calcula distância em metros entre usuário e ATM usando fórmula Haversine.
     * Muito mais preciso que distância euclidiana para coordenadas geográficas.
     */
    fun calculateDistanceToATM(userLocation: UserLocation, atmLatitude: Double, atmLongitude: Double): Double {
        val earthRadius = 6371_000.0  // metros

        val dLat = Math.toRadians(atmLatitude - userLocation.latitude)
        val dLon = Math.toRadians(atmLongitude - userLocation.longitude)

        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(userLocation.latitude)) *
                cos(Math.toRadians(atmLatitude)) *
                sin(dLon / 2).pow(2)

        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return earthRadius * c
    }

    /**
     * Verifica se o usuário está próximo o suficiente para realizar saque.
     * Combina distância GPS com RSSI BLE para maior precisão.
     */
    fun validateProximity(
        userLocation: UserLocation,
        atmLatitude:  Double,
        atmLongitude: Double,
        bleRssi:      Int
    ): ProximityResult {
        val gpsDistance  = calculateDistanceToATM(userLocation, atmLatitude, atmLongitude)
        val bleDistance  = rssiToDistance(bleRssi)
        val fusedDistance = (gpsDistance * 0.4 + bleDistance * 0.6)  // fusão ponderada GPS+BLE

        return ProximityResult(
            gpsDistanceMeters  = gpsDistance,
            bleDistanceMeters  = bleDistance,
            fusedDistanceMeters = fusedDistance,
            isWithinRange      = fusedDistance <= MAX_DISTANCE_METERS,
            isIdealRange       = fusedDistance <= IDEAL_DISTANCE_METERS,
            accuracy           = userLocation.accuracy
        )
    }

    // -------------------------------------------------------------------------
    // GEOFENCES
    // -------------------------------------------------------------------------

    /**
     * Registra geofences para uma lista de ATMs.
     * Dispara alerta quando usuário entra no raio de cada ATM.
     */
    fun registerATMGeofences(atms: List<ATMGeoPoint>) {
        if (!checkPermissions()) return

        val geofences = atms.map { atm ->
            Geofence.Builder()
                .setRequestId(atm.id)
                .setCircularRegion(atm.latitude, atm.longitude, GEOFENCE_RADIUS_M)
                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_EXIT)
                .setExpirationDuration(Geofence.NEVER_EXPIRE)
                .build()
        }

        val request = GeofencingRequest.Builder()
            .addGeofences(geofences)
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .build()

        // geofencingClient.addGeofences(request, geofencePendingIntent)
    }

    // -------------------------------------------------------------------------
    // INTERNALS
    // -------------------------------------------------------------------------

    private fun rssiToDistance(rssi: Int): Double {
        val txPower = -59.0
        val n = 2.0
        return 10.0.pow((txPower - rssi) / (10.0 * n))
    }

    private fun checkPermissions(): Boolean {
        return ActivityCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    // Task extension para coroutines
    private suspend fun <T> com.google.android.gms.tasks.Task<T>.await(): T? {
        return kotlinx.coroutines.suspendCancellableCoroutine { cont ->
            addOnSuccessListener { cont.resume(it) { } }
            addOnFailureListener { cont.resume(null) { } }
        }
    }
}

// =============================================================================
// DATA CLASSES
// =============================================================================

data class UserLocation(
    val latitude:  Double,
    val longitude: Double,
    val accuracy:  Float,
    val altitude:  Double,
    val timestamp: Long
)

data class ATMGeoPoint(
    val id:        String,
    val latitude:  Double,
    val longitude: Double,
    val address:   String
)

data class ProximityResult(
    val gpsDistanceMeters:   Double,
    val bleDistanceMeters:   Double,
    val fusedDistanceMeters: Double,
    val isWithinRange:       Boolean,
    val isIdealRange:        Boolean,
    val accuracy:            Float
)

sealed class GeoState {
    object Idle                         : GeoState()
    object Requesting                   : GeoState()
    data class Active(val loc: UserLocation) : GeoState()
    data class Error(val msg: String)   : GeoState()
}
